import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import api from "@/lib/api";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Calendar, ExternalLink, Link2Off, CheckCircle2, Loader2, Save, RotateCcw, User, Clock, Settings as SettingsIcon } from "lucide-react";

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

interface Slot {
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  slotDuration: number;
  bufferBetween: number;
  isActive: boolean;
}

type Tab = "profile" | "availability" | "calendar";

export default function MySettings() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<Tab>("profile");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">My Settings</h1>
        <p className="text-muted-foreground text-sm">Manage your profile, availability, and connected services</p>
      </div>

      <div className="flex gap-1 rounded-lg border p-1 w-fit">
        {[
          { id: "profile" as Tab, label: "Profile", icon: User },
          { id: "availability" as Tab, label: "My Availability", icon: Clock },
          { id: "calendar" as Tab, label: "Calendar", icon: Calendar },
        ].map((tab) => (
          <Button
            key={tab.id}
            variant={activeTab === tab.id ? "default" : "ghost"}
            size="sm"
            onClick={() => setActiveTab(tab.id)}
          >
            <tab.icon className="mr-1.5 h-4 w-4" />
            {tab.label}
          </Button>
        ))}
      </div>

      {activeTab === "profile" && <ProfileSection />}
      {activeTab === "availability" && <AvailabilitySection />}
      {activeTab === "calendar" && <CalendarSection />}
    </div>
  );
}

function ProfileSection() {
  const { user } = useAuth();
  const [name, setName] = useState(user?.name || "");
  const [phone, setPhone] = useState(user?.phone || "");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");

  const updateMutation = useMutation({
    mutationFn: (data: { name: string; phone: string }) => api.put("/auth/profile", data),
    onSuccess: () => { toast.success("Profile updated"); },
    onError: (err: any) => toast.error(err?.response?.data?.message || "Failed to update"),
  });

  const passwordMutation = useMutation({
    mutationFn: (data: { currentPassword: string; newPassword: string }) => api.post("/auth/change-password", data),
    onSuccess: () => { setCurrentPassword(""); setNewPassword(""); toast.success("Password changed"); },
    onError: (err: any) => toast.error(err?.response?.data?.message || "Failed to change password"),
  });

  return (
    <div className="space-y-6 max-w-2xl">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Personal Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label className="text-xs">Name</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Email</Label>
              <Input value={user?.email || ""} disabled className="bg-gray-50" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Phone</Label>
              <Input value={phone} onChange={(e) => setPhone(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Role</Label>
              <Input value={user?.role || ""} disabled className="bg-gray-50 capitalize" />
            </div>
            {user?.profession && (
              <div className="space-y-1">
                <Label className="text-xs">Profession</Label>
                <Input value={user.profession} disabled className="bg-gray-50" />
              </div>
            )}
          </div>
          <Button size="sm" onClick={() => updateMutation.mutate({ name, phone })} disabled={updateMutation.isPending}>
            {updateMutation.isPending ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Save className="mr-1 h-4 w-4" />}
            Save Changes
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Change Password</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label className="text-xs">Current Password</Label>
              <Input type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">New Password</Label>
              <Input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
            </div>
          </div>
          <Button size="sm" variant="outline" onClick={() => passwordMutation.mutate({ currentPassword, newPassword })} disabled={passwordMutation.isPending || !currentPassword || !newPassword}>
            Change Password
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

function AvailabilitySection() {
  const queryClient = useQueryClient();
  const [slots, setSlots] = useState<Slot[]>(() =>
    DAYS.map((_, i) => ({ dayOfWeek: i, startTime: "09:00", endTime: "17:00", slotDuration: 30, bufferBetween: 0, isActive: i > 0 && i < 6 }))
  );

  const { data: mySchedule, isLoading } = useQuery({
    queryKey: ["my-availability"],
    queryFn: () => api.get("/availability/me").then((r) => r.data),
  });

  useEffect(() => {
    if (mySchedule?.schedule) {
      setSlots(
        DAYS.map((_, i) => {
          const existing = mySchedule.schedule.find((a: any) => a.dayOfWeek === i);
          return existing
            ? { dayOfWeek: i, startTime: existing.startTime, endTime: existing.endTime, slotDuration: existing.slotDuration || 30, bufferBetween: existing.bufferBetween || 0, isActive: existing.isActive }
            : { dayOfWeek: i, startTime: "09:00", endTime: "17:00", slotDuration: 30, bufferBetween: 0, isActive: false };
        })
      );
    }
  }, [mySchedule]);

  const saveMutation = useMutation({
    mutationFn: (data: { slots: Slot[] }) => api.put("/availability/me", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["my-availability"] });
      toast.success("Your availability updated");
    },
    onError: (err: any) => toast.error(err?.response?.data?.message || "Failed to save"),
  });

  const resetMutation = useMutation({
    mutationFn: () => api.delete("/availability/me"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["my-availability"] });
      toast.success("Reset to org defaults");
    },
    onError: (err: any) => toast.error(err?.response?.data?.message || "Failed to reset"),
  });

  function updateSlot(index: number, field: keyof Slot, value: any) {
    setSlots((prev) => {
      const next = [...prev];
      next[index] = { ...next[index], [field]: value };
      return next;
    });
  }

  if (isLoading) {
    return <div className="flex items-center gap-2 text-sm text-gray-400"><Loader2 className="h-4 w-4 animate-spin" /> Loading your schedule...</div>;
  }

  return (
    <div className="space-y-4 max-w-3xl">
      <Card>
        <CardHeader className="pb-2 flex flex-row items-center justify-between">
          <CardTitle className="text-sm">My Weekly Hours</CardTitle>
          <div className="flex items-center gap-2">
            <Button size="sm" onClick={() => saveMutation.mutate({ slots })} disabled={saveMutation.isPending}>
              <Save className="mr-1 h-4 w-4" /> {saveMutation.isPending ? "Saving..." : "Save"}
            </Button>
            <Button size="sm" variant="outline" onClick={() => resetMutation.mutate()} disabled={resetMutation.isPending}>
              <RotateCcw className="mr-1 h-4 w-4" /> Reset to Default
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-gray-400 mb-4">
            Set the hours you're available for appointments. These override the organization's default schedule.
          </p>
          <div className="space-y-2">
            {slots.map((slot, i) => (
              <div key={i} className="flex items-center gap-3 rounded-lg border p-2.5">
                <div className="w-24 shrink-0">
                  <Label className="text-xs font-medium">{DAYS[slot.dayOfWeek]}</Label>
                </div>
                <label className="flex items-center gap-2 shrink-0">
                  <input type="checkbox" checked={slot.isActive}
                    onChange={(e) => updateSlot(i, "isActive", e.target.checked)}
                    className="h-4 w-4 rounded border-gray-300 text-primary" />
                </label>
                <div className="flex items-center gap-2">
                  <Input type="time" value={slot.startTime}
                    onChange={(e) => updateSlot(i, "startTime", e.target.value)}
                    className="h-8 w-24 text-xs" disabled={!slot.isActive} />
                  <span className="text-xs text-gray-400">to</span>
                  <Input type="time" value={slot.endTime}
                    onChange={(e) => updateSlot(i, "endTime", e.target.value)}
                    className="h-8 w-24 text-xs" disabled={!slot.isActive} />
                </div>
                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <span>Slot:</span>
                  <Input type="number" value={slot.slotDuration}
                    onChange={(e) => updateSlot(i, "slotDuration", Number(e.target.value))}
                    className="h-8 w-16 text-xs" disabled={!slot.isActive} />
                  <span>min</span>
                </div>
                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <span>Buffer:</span>
                  <Input type="number" value={slot.bufferBetween}
                    onChange={(e) => updateSlot(i, "bufferBetween", Number(e.target.value))}
                    className="h-8 w-16 text-xs" disabled={!slot.isActive} />
                  <span>min</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function CalendarSection() {
  const [syncing, setSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState<any>(null);

  const { data: statusData, isLoading, refetch } = useQuery({
    queryKey: ["calendar-status"],
    queryFn: () => api.get("/calendar/status").then((r) => r.data),
  });

  const disconnectMutation = useMutation({
    mutationFn: () => api.post("/calendar/disconnect"),
    onSuccess: () => {
      refetch();
      toast.success("Google Calendar disconnected");
    },
    onError: (err: any) => toast.error(err?.response?.data?.message || "Failed to disconnect"),
  });

  async function handleConnect() {
    try {
      const { data } = await api.get("/calendar/auth-url");
      if (data.url) {
        window.location.href = data.url;
      } else {
        toast.error("Failed to get auth URL");
      }
    } catch (err: any) {
      toast.error(err?.response?.data?.message || "Failed to connect");
    }
  }

  async function handleSync() {
    setSyncing(true);
    setSyncResult(null);
    try {
      const { data } = await api.post("/calendar/sync");
      setSyncResult(data);
      toast.success("Sync completed");
    } catch (err: any) {
      toast.error(err?.response?.data?.message || "Sync failed");
    } finally {
      setSyncing(false);
    }
  }

  const connected = statusData?.connected;
  const email = statusData?.email;

  return (
    <div className="space-y-4 max-w-2xl">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Google Calendar</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {isLoading ? (
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <Loader2 className="h-4 w-4 animate-spin" /> Loading...
            </div>
          ) : connected ? (
            <div className="space-y-4">
              <div className="flex items-center gap-3 rounded-lg border border-emerald-200 bg-emerald-50 p-3">
                <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                <div>
                  <p className="text-sm font-medium text-emerald-800">Connected</p>
                  {email && <p className="text-xs text-emerald-600">{email}</p>}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={handleSync} disabled={syncing}>
                  {syncing ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Calendar className="mr-1 h-4 w-4" />}
                  Sync Now
                </Button>
                <Button variant="destructive" size="sm" onClick={() => disconnectMutation.mutate()}>
                  <Link2Off className="mr-1 h-4 w-4" /> Disconnect
                </Button>
              </div>
              {syncResult && (
                <div className="rounded-lg border bg-gray-50 p-3 text-xs text-gray-600">
                  <p>Outbound: {syncResult.outboundCreated} created, {syncResult.outboundUpdated} updated</p>
                  <p>Inbound: {syncResult.inboundCreated} created, {syncResult.inboundUpdated} updated</p>
                  {syncResult.errors > 0 && <p className="text-red-500">{syncResult.errors} errors</p>}
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              <p className="text-sm text-gray-500">
                Connect your Google Calendar to automatically sync appointments between Oriveo and Google Calendar.
              </p>
              <Button onClick={handleConnect}>
                <Calendar className="mr-2 h-4 w-4" /> Connect Google Calendar
              </Button>
              <p className="text-xs text-gray-400">
                You'll be redirected to Google to authorize access. Only calendar events are read and written.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
